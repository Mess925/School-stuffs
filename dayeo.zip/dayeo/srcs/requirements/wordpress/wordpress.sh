#!/bin/bash

export WORDPRESS_ADMIN_PASSWORD=$(cat /run/secrets/wordpress_admin_password.txt)
export WORDPRESS_USER_PASSWORD=$(cat /run/secrets/wordpress_user_password.txt)
export DB_PASSWORD=$(cat /run/secrets/db_password.txt)
export DB_ROOT_PASSWORD=$(cat /run/secrets/db_root_password.txt)

echo "Waiting for MariaDB (TCP) ..."
until mysqladmin ping -h"$DB_HOST" -u"$DB_USER" -p"$DB_PASSWORD" --silent; do
  echo "MariaDB not ready yet, retrying..."
  sleep 2
done
echo "MariaDB is reachable!"

# Ensure required environment variables are set
: "${DATABASE:?Need to set DATABASE}"
: "${DB_USER:?Need to set DB_USER}"
: "${DB_PASSWORD:?Need to set DB_PASSWORD}"
: "${DB_HOST:?Need to set DB_HOST}"
: "${WORDPRESS_URL:?Need to set WORDPRESS_URL}"
: "${WORDPRESS_ADMIN:?Need to set WORDPRESS_ADMIN}"
: "${WORDPRESS_ADMIN_PASSWORD:?Need to set WORDPRESS_ADMIN_PASSWORD}"
: "${WORDPRESS_USER_EMAIL:?Need to set WORDPRESS_USER_EMAIL}"
: "${WORDPRESS_USER_PASSWORD:?Need to set WORDPRESS_USER_PASSWORD}"
# Admin email defaults to regular user email if not provided
: "${WORDPRESS_ADMIN_EMAIL:=$WORDPRESS_USER_EMAIL}"
# Optional: site title (defaults to "Inception")
: "${WORDPRESS_TITLE:=Inception}"
# Default regular username derived from email if not set
if [ -z "$WORDPRESS_USER" ] && [ -n "$WORDPRESS_USER_EMAIL" ]; then
  WORDPRESS_USER=$(echo "$WORDPRESS_USER_EMAIL" | cut -d'@' -f1)
fi

# Create wp-config.php from sample
cp /var/www/html/wp-config-sample.php /var/www/html/wp-config.php
echo "Configuring wp-config.php..."
# Update database settings in wp-config.php
sed -i "s/database_name_here/$DATABASE/" /var/www/html/wp-config.php
sed -i "s/username_here/$DB_USER/" /var/www/html/wp-config.php
sed -i "s/password_here/$DB_PASSWORD/" /var/www/html/wp-config.php
sed -i "s/localhost/$DB_HOST/" /var/www/html/wp-config.php
echo "wp-config.php configured."
# Set proper ownership
chown -R www-data:www-data /var/www/html
echo "Ownership set to www-data."

# Install / configure WordPress when database is ready
cd /var/www/html

# Use WP-CLI to install WordPress if not already installed
if command -v wp >/dev/null 2>&1; then
  echo "WP-CLI found, checking installation..."
  if ! wp core is-installed --allow-root --path=/var/www/html >/dev/null 2>&1; then
    echo "Installing WordPress with title \"$WORDPRESS_TITLE\"..."
    wp core install --url="$WORDPRESS_URL" --title="$WORDPRESS_TITLE" --admin_user="$WORDPRESS_ADMIN" --admin_password="$WORDPRESS_ADMIN_PASSWORD" --admin_email="$WORDPRESS_ADMIN_EMAIL" --skip-email --allow-root --path=/var/www/html
    echo "WordPress installed."
  else
    echo "WordPress already installed. Ensuring site title is correct..."
    current_title=$(wp option get blogname --allow-root --path=/var/www/html 2>/dev/null || echo "")
    if [ "$current_title" != "$WORDPRESS_TITLE" ]; then
      echo "Updating site title from \"$current_title\" to \"$WORDPRESS_TITLE\"..."
      wp option update blogname "$WORDPRESS_TITLE" --allow-root --path=/var/www/html || echo "Failed to update title"
    else
      echo "Site title already set to \"$WORDPRESS_TITLE\"."
    fi
  fi

  # Ensure admin user exists and has administrator role
  if ! wp user get "$WORDPRESS_ADMIN" --allow-root --path=/var/www/html >/dev/null 2>&1; then
    echo "Creating admin user..."
    wp user create "$WORDPRESS_ADMIN" "$WORDPRESS_ADMIN_EMAIL" --user_pass="$WORDPRESS_ADMIN_PASSWORD" --role=administrator --allow-root --path=/var/www/html
    echo "Admin user created."
  else
    echo "Admin user exists, ensuring administrator role."
    wp user set-role "$WORDPRESS_ADMIN" administrator --allow-root --path=/var/www/html || true
  fi

  if [ -n "$WORDPRESS_USER_EMAIL" ] && [ -n "$WORDPRESS_USER_PASSWORD" ]; then
    if ! wp user get "$WORDPRESS_USER" --allow-root --path=/var/www/html >/dev/null 2>&1; then
      echo "Creating user '$WORDPRESS_USER'..."
      wp user create "$WORDPRESS_USER" "$WORDPRESS_USER_EMAIL" --user_pass="$WORDPRESS_USER_PASSWORD" --role=subscriber --allow-root --path=/var/www/html && echo "User '$WORDPRESS_USER' created." || echo "Failed to create user '$WORDPRESS_USER'."
    else
      echo "User '$WORDPRESS_USER' already exists."
    fi
  else
    echo "Skipping additional user creation (missing WORDPRESS_USER_EMAIL or WORDPRESS_USER_PASSWORD)."
  fi
else
  echo "WP-CLI not found; skipping automated install and user creation."
fi
# Start PHP-FPM in the foreground
php-fpm8.2 -F