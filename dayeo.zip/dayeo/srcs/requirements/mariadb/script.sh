#!/bin/bash

export DB_PASSWORD=$(cat /run/secrets/db_password.txt)
export DB_ROOT_PASSWORD=$(cat /run/secrets/db_root_password.txt)

echo "DATABASE=$DATABASE"
echo "DB_USER=$DB_USER"

# Start MariaDB in the background
mysqld_safe &
MARIADB_PID=$!

echo "Waiting for MariaDB to start..."
sleep 5

# Wait until MySQL is responsive
until mysql -u root -e "SELECT 1" &>/dev/null; do
    echo "MariaDB is unavailable, retrying..."
    sleep 2
done

echo "MariaDB is ready!"

# Create database and user
echo "Setting up database..."
mysql -u root -e "CREATE DATABASE IF NOT EXISTS $DATABASE;"
mysql -u root -e "CREATE USER IF NOT EXISTS '$DB_USER'@'%' IDENTIFIED BY '$DB_PASSWORD';"
mysql -u root -e "GRANT ALL PRIVILEGES ON $DATABASE.* TO '$DB_USER'@'%';"
mysql -u root -e "FLUSH PRIVILEGES;"
mysql -u root -e "ALTER USER 'root'@'localhost' IDENTIFIED BY '$DB_ROOT_PASSWORD';"

echo "Database setup complete!"

# Keep MariaDB running in foreground
wait $MARIADB_PID
