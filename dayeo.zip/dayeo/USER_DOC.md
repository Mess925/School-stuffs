# Inception — User Documentation

Summary
- Inception runs a 3-container web stack: NGINX , MariaDB and WordPres.
- Main site URL: https://hthant.42.fr 

What services provide
- NGINX: terminates TLS, serves static files and proxies PHP to WordPress.
- WordPress: PHP application (serves the website and WP admin).
- MariaDB: MySQL-compatible database holding WordPress data.

Start and stop the project
- Start (build & run in background):
  make up /make
- Stop (containers only):
  make down 
- Full reset (remove containers, volumes and images — data loss):
  make fclean
- Rebuild from scratch:
  make re

Accessing the website and admin panel
- Site: open https://hthant.42.fr in a browser.
- Admin dashboard: https://hthant.42.fr/wp-admin

- Default admin user and email (from srcs/.env):
  - Admin username: han_wp
  - Admin email: hanminthant222@gmail.com

- Secondary WordPress user (from srcs/.env):
  - Username: hthant_user
  - Email: han@gmail.com

Locate and manage credentials
- Environment file (service config): srcs/.env
  - DATABASE=hthant_db
  - DB_HOST=mariadb
  - DB_USER=thant_user
  - WORDPRESS_URL=https://hthant.42.fr
- Secrets (not tracked in .env): stored in the repository's secrets/ directory and referenced by docker-compose as Docker secrets.
  - secrets/db_password.txt
  - secrets/db_root_password.txt
  - secrets/wordpress_admin_password.txt
  - secrets/wordpress_user_password.txt
- To view a secret on the host:
  cat secrets/wordpress_admin_password.txt
- Change a secret: replace the file contents, then recreate affected services:
  make fclean && make up

Check services are running correctly
- Check all the docker files are running 
  docker ps
- if smth is worng 
  docker logs <image name>

Common troubleshooting
- Permission errors on host volumes:
  sudo chown -R $(id -u):$(id -g) /home/hthant/data/wp /home/hthant/data/db
- Secrets not applied: ensure docker-compose references files in ../secrets and restart with make re.

Quick commands
- Start: make up
- Stop: make down
- Full reset: make fclean