# Inception — Developer Documentation

Purpose
- How to set up, build, run and develop the Inception Docker stack (NGINX + MariaDB + WordPress).

Prerequisites (from scratch)
- Linux workstation.
- Install Docker and Docker Compose (or Docker CLI with Compose plugin).
  - Example (Debian/Ubuntu):
    sudo apt update
    sudo apt install -y docker.io docker-compose
    sudo systemctl enable --now docker
- git, make, bash.
- Ensure your user can run docker (either use sudo or add user to docker group).

Configuration files & secrets
- Main compose and env:
  - srcs/docker-compose.yml
  - srcs/.env (values used by containers; example entries)
    - DATABASE=hthant_db
    - DB_HOST=mariadb
    - DB_USER=thant_user
    - DOMAIN_NAME=user
.42.fr
    - WORDPRESS_ADMIN=han_wp
    - WORDPRESS_ADMIN_EMAIL=hanminthant222@gmail.com
    - WORDPRESS_USER=hthant_user
    - WORDPRESS_USER_EMAIL=han@gmail.com
    - WORDPRESS_URL=https://user
.42.fr
- Secrets: local files in secrets/ (these are mapped as Docker secrets)
  - secrets/db_password.txt
  - secrets/db_root_password.txt
  - secrets/wordpress_admin_password.txt
  - secrets/wordpress_user_password.txt
- Host data directories (persisted volumes):
  - /home/user
/data/wp  → WordPress files (wp-content, themes, plugins)
  - /home/user
/data/db  → MariaDB data files

Set up environment (first time)
1. Clone repository and cd into project root.
2. Create secrets files (if not present) and set secure permissions:
   mkdir -p secrets
   echo '<db_root_password>' > secrets/db_root_password.txt
   echo '<db_password>' > secrets/db_password.txt
   echo '<wp_admin_pass>' > secrets/wordpress_admin_password.txt
   echo '<wp_user_pass>' > secrets/wordpress_user_password.txt
   chmod 600 secrets/*.txt
3. Ensure host data dirs exist and have proper ownership:
   sudo mkdir -p /home/user
/data/wp /home/user
/data/db
   sudo chown -R $(id -u):$(id -g) /home/user
/data/wp /home/user
/data/db

Build and launch (Makefile + Docker Compose)
- Build and start all services:
  make up
  (runs docker compose -f srcs/docker-compose.yml up --build -d)
- Stop containers:
  make down
- Remove containers + volumes (service volumes only):
  make clean
- Full cleanup (containers, volumes, images → data reset):
  make fclean
- Rebuild from scratch:
  make re

Useful docker-compose commands
- Exec into a container:
  docker exec -it wordpress bash
  docker exec -it mariadb bash

Data persistence and where things live
- WordPress files persist on host: /home/user/data/wp (bind mount via compose).
- MariaDB data persists on host: /home/user/data/db (bind mount).
- Database name and credentials come from srcs/.env and secrets/*.txt; changing them often requires reinitializing the DB (make fclean).

Development workflow tips
- Code iteration (PHP/theme/plugin):
  - Edit files in /home/user
/data/wp on host; changes are immediate in container.
  - If PHP-FPM needs to be restarted: docker compose -f srcs/docker-compose.yml restart wordpress
- Changing Dockerfiles or bootstrap scripts:
  - Modify files under srcs/requirements/<service>/ then rebuild that service:
    docker compose -f srcs/docker-compose.yml up --build -d <service>
- Database schema changes:
  - Import dumps into mariadb:
    docker compose -f srcs/docker-compose.yml exec -T mariadb mysql -u root -p$(cat secrets/db_root_password.txt) < /path/on/host/dump.sql
  - For a clean DB reset: make fclean && make up

Debugging
- Check logs first:
  docker compose -f srcs/docker-compose.yml logs <service>
- Check container health and readiness loops located in:
  - srcs/requirements/mariadb/script.sh
  - srcs/requirements/wordpress/wordpress.sh
- Fixing permission issues on bind mounts:
  sudo chown -R $(id -u):$(id -g) /home/user
/data/wp /home/user
/data/db

CI, testing and best practices
- Do not commit secrets; store them in CI secret store or vault.
- Pin base images in Dockerfiles for reproducible builds.
- Add unit tests (PHPUnit) and linters (phpstan, php-cs-fixer) and run them in CI.
- Add a Makefile target to run tests inside a transient container.

Where to change behavior
- WordPress bootstrap and WP-CLI automation: srcs/requirements/wordpress/wordpress.sh
- MariaDB bootstrap and initialization: srcs/requirements/mariadb/script.sh
- NGINX configuration: srcs/requirements/nginx/nginx.conf
- Compose wiring and volumes: srcs/docker-compose.yml

Contact / further info
- Read README.md and existing docs in srcs/ for implementation details.