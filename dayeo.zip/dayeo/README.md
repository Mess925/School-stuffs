This project has been created as part of the 42 curriculum by hthant.

DESCRIPTION

In my belief this project is to understand about containers and how they works. The goal is to host a fully functional server using docker containers.

INSTRUCTIONS

So as the subject states we have to create 3 docker containers 2 volumes and a network connections between them.

For compilation we are using docker compose and makefile so makefile is the same as before. But in here instead of compiling the files it call the docker compose which will up and run the docker containers.In IRL we use docker desktop to trace and check the containers, images, etc.But in 42 we are going to use docker CLI like docker run -t ....., docker compose ......, docker images...., docker system .......

For Installation we need a VM because we need to use sudo. And we install docker obviously because we are going to build docker containers. After that we create dockerfiles acording to the subject.

For execution we write the docker compose file which will build and run all the containers. And a makefile as well.

RESOURCES

How to write a dockerfile
https://docs.docker.com/get-started/docker-concepts/building-images/writing-a-dockerfile/

What is a container
https://www.docker.com/resources/what-container/

About images
https://docs.docker.com/get-started/introduction/build-and-push-first-image/

Docker compose
https://docs.docker.com/compose/

Rules for docker file
https://docs.docker.com/reference/dockerfile/

I used AI to gide me how to write the makefile for docker compose up, build and down.

Techniacl Choices

So in inception when you write dockerfile you are free to choose the either debian or alpine.
For my nginx I chose alpine cuz everyone knows that is light weight and nginx is just a proxy server so nth much isneeded and it is more secure than debian.
For database MariaDB and wordpress php-fpm I chose debian.
One reason to choose that is devian install some packages that I would need for my DB. 
And another one is I wanted to try both and it has more stability than alpine.

Virtual Machine vs Docker
https://www.atlassian.com/microservices/cloud-computing/containers-vs-vms

Secrets vs Environment Variables
https://www.youtube.com/watch?v=1mKJjQStGmg

Docker Network vs Host Network
https://docs.docker.com/engine/network/drivers/host/
https://docs.docker.com/engine/network/drivers/bridge/

Docker Volumes vs Bind Mounts
https://www.geeksforgeeks.org/devops/docker-volume-vs-bind-mount/